﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Resources;
using System.Text;
using System.Threading.Tasks;

namespace williams_bookstore
{
    public class Program
    {
        static void Main(string[] args)
        {
            //string[] employeeType = {"Salesperson", "Supervisor" };
            Employee[] employeeType = new Employee[2];
            string name, surname;
            double hoursWorked, hoursRate;
            //int input;

            Console.Write("What is your name? ");
            name = Console.ReadLine();
            Console.Write("What is your surname? ");
            surname = Console.ReadLine();
            Console.WriteLine("How many hours do you work? ");
            hoursWorked = double.Parse(Console.ReadLine());
            Console.WriteLine("How much is your hourly rate? ");
            hoursRate = double.Parse(Console.ReadLine());

        }
    }
}
