﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace williams_bookstore
{
    public class Employee
    {
        //data members
        private string name;
        private string surname;
        private double hoursWorked;
        private double hoursRate;
        private double bonus;
        private double totalSalery;

        //properties
        public string Name { get { return name; } set {  name = value; } }
        public string Surname { get {  return surname; } set {  surname = value; } }
        public double HoursWorked { get {  return hoursWorked; } set {  hoursWorked = value; } }
        public double HoursRate { get {  return hoursRate; } set { hoursRate = value; } }
        public double Bonus { get {  return bonus; } set { bonus = value; } }
        public double getTotalSalary { get { return totalSalery; } }
        public void setTotalSalary()
        {
            totalSalery = hoursWorked * hoursRate;
        }
        public void setTotalSalary(double bonus)
        {
            totalSalery = (hoursWorked * hoursRate) + bonus;
        }

        //constractor overload
        //Info for Salesperson
        public Employee(string name, string surname, double hoursWorked, double hoursRate)
        {
            this.name = name;
            this.surname = surname;
            this.hoursWorked = hoursWorked;
            this.hoursRate = hoursRate;
        }


        //Info for Supervisor
        public Employee(string name, string surname, double hoursWorked, double hoursRate, double bonus)
        {
            this.name = name;
            this.surname = surname;
            this.hoursWorked = hoursWorked;
            this.hoursRate = hoursRate;
            bonus = 1400;
            this.bonus = bonus;
        }
    }
}
