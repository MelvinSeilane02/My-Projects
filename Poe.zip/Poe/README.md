# Contract Monthly Claim System (CMCS)
Overview
The Contract Monthly Claim System (CMCS) is a .NET-based application designed to streamline the process of submitting, approving, and tracking monthly claims for Independent Contractor (IC) lecturers. The system allows lecturers to submit their claims for hours worked, upload supporting documents, and track the status of their claims. It also provides functionality for Program Coordinators and Academic Managers to review and approve claims, ensuring a smooth and transparent process.

Features
Lecturer Claim Submission: IC lecturers can submit their monthly claims by entering total hours worked and uploading supporting documents.
Program Coordinator & Manager Approval: Claims are reviewed and approved by Program Coordinators and Academic Managers to ensure accuracy.
Document Upload: Lecturers can upload supporting documents, such as timesheets, to accompany their claims.
Claim Status Tracking: Lecturers can track the status of their claims (e.g., Pending, Approved, Rejected) until they are fully settled.
User Roles: The system supports multiple user roles, including Lecturers, Program Coordinators, and Academic Managers.
Consistent and Reliable Information: All information within the system is displayed consistently and reliably, improving transparency.
User Interface Design
Color Theme: The system uses a blue and black color scheme with white text to create a professional and modern look.
Large Buttons: The UI features large, easy-to-click buttons to improve accessibility and ease of use.
White Labels: White labels are used to ensure text is legible against the dark background, improving user experience.

# Usage
# Starting the Application
After launching the application, you'll be greeted with the Start Window. Simply click the Start button to proceed to the login window.
# Lecturer Functionality
Submit Claims: Navigate to the claim submission section, enter the total hours worked, and upload any supporting documents (e.g., timesheets).
Track Claim Status: After submission, you can view the status of your claim on your dashboard.
# Program Coordinator & Manager Functionality
Review Claims: Coordinators and Managers can view pending claims submitted by lecturers.
Approve or Reject Claims: Claims can be reviewed, approved, or rejected, with notes provided for each action.
