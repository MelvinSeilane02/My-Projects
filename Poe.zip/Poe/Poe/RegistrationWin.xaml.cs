﻿using Claims_Library;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Contract_Monthly_Claim_System
{
    /// <summary>
    /// Interaction logic for RegistrationWin.xaml
    /// </summary>
    public partial class RegistrationWin : Window
    {
       private string LoginFile = "..//..//..//..//Txt_Files//Login_info.txt";

        private string[,] userInfo;
        public RegistrationWin()
        {
            InitializeComponent();

           
            List<string> FileInfo = new List<string>();
            cmbGender.SelectedIndex = -1;
            cmbDepartment.SelectedIndex = -1;
            try
            {
                // Open the file for reading
                using (StreamReader reader = new StreamReader(LoginFile))
                {
                    string line;

                    // Read each line until the end of the file
                    while ((line = reader.ReadLine()) != null)
                    {
                        FileInfo.Add(line);
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions (like file not found, etc.)
                Console.WriteLine($"An error occurred: {ex.Message}");
            }

            numOfUsers = FileInfo.Count/8;
            userInfo = new string[numOfUsers, 8];

            for (int i = 0; i < numOfUsers; i++)
            {
                for (int j = 0; j < userInfo.GetLength(1); j++)
                {
                    int index = (i * 7) + j;
                    userInfo[(i), j] = FileInfo[index];
                }
                users.Add(new User(userInfo[i, 0], userInfo[i, 1], userInfo[i, 2], userInfo[i, 3], userInfo[i, 4], userInfo[i, 5], userInfo[i, 6], userInfo[i, 7]));
            }

            for (int i = 0; i <= numOfUsers; i++)
            {
                //if((numOfUsers > 0))
                    //users.Add(new User(userInfo[i, 0], userInfo[i,1], userInfo[i,2] , userInfo[i,3], userInfo[i,4], userInfo[i,5], userInfo[i,6], userInfo[i,7]));
                
            }

        }

        private List<User> users = new List<User>();
        private int numOfUsers;

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            // Generate unique UserID
            string userID = GenerateUniqueUserID();
            //txtUserID.Text = userID; // Display the generated UserID in the textbox

            // Retrieve other input values
            string name = txtName.Text;
            string surname = txtSurname.Text;
            string gender = (cmbGender.SelectedItem as ComboBoxItem)?.Content.ToString();
            string email = txtEmail.Text;
            ComboBoxItem selectedDepartment = (ComboBoxItem)cmbDepartment.SelectedItem;
            string department = selectedDepartment?.Content.ToString();
            string username = GenerateUsername(name, surname); // Generate username
            //txtUsername.Text = username; // Display the generated username in the Username field
            string password = txtPassword.Password;

            // Validate other inputs
            if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(surname) ||
                string.IsNullOrWhiteSpace(gender) || string.IsNullOrWhiteSpace(email) ||
                string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password) || string.IsNullOrWhiteSpace(department))
            {
                MessageBox.Show("Please fill all fields!", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            MessageBox.Show($"users.Count is {users.Count}");
            //MessageBox.Show($"userInfo[i, 6] is {userInfo[i, 6]}");
            for (int i = 0; i < users.Count; i++)
            {
                MessageBox.Show($"userInfo[i, 6] is {userInfo[i, 6]}");
                if(username == userInfo[i, 6])
                {
                    MessageBox.Show("Username already exist.", "", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

            }

            // Simulate registration (you can save the data or perform further actions here)
            MessageBox.Show($"User {name} {surname} registered successfully with UserID: {userID} and Username: {username}!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);

            

            // Add the generated UserID to the existing list
            users.Add(new User(userID, name, surname, gender, email, department, username, password));
            
            try
            {
                using (StreamWriter WritingToFile = new StreamWriter(LoginFile,true))
                {
                    WritingToFile.WriteLine($"{userID}\n{name}\n{surname}\n{gender}\n{email}\n{department}\n{username}\n{password}");
                }
            }
            catch(Exception ex) 
            {
                MessageBox.Show($"ERROR: {ex.Message}");
            }

            this.Close();

            // Clear the form after registration
            ClearFields();
        }

        private string GenerateUsername(string name, string surname)
        {
            string firstPart = name.Length >= 4 ? name.Substring(0, 4) : name; // First 4 letters of name (or full name if shorter)
            string secondPart = surname; 

            return $"{firstPart}{secondPart}"; // Concatenate both parts
        }

        // Generate a unique UserID
        private string GenerateUniqueUserID()
        {
            string newUserID;
            Random random = new Random();

            
            while (true) 
            {
                int randomNumber = random.Next(10000, 99999); // Generate a 5-digit random number
                newUserID = $"UI{randomNumber}"; // Prefix with 'UI'
                //MessageBox.Show($"The newUserID is {newUserID}", "Error");


                for (int i = 0; i < users.Count; ++i)
                {
                    if (newUserID.Equals(users[i].userID))
                    {
                        newUserID = "";
                        MessageBox.Show($"The newUserID is {newUserID}", "Error");
                    }
                    else
                    {
                        // Ensure UserID is unique
                        break;
                    }
                }
                if (!(String.IsNullOrEmpty(newUserID))) 
                { break; }

            }
            return newUserID;
        }

        // Clear input fields
        private void ClearFields()
        {
            //txtUserID.Clear(); // Reset UserID field
            txtName.Clear();
            txtSurname.Clear();
            cmbGender.SelectedIndex = -1; // Deselect gender
            txtEmail.Clear();
            cmbDepartment.SelectedIndex = -1; // Deselect department
            txtPassword.Clear();
        }
    }
}
