<<<<<<<< HEAD:Poe/ForgotPassWin.xaml.cs
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Contract_Monthly_Claim_System
{
    /// <summary>
    /// Interaction logic for ForgotPassWin.xaml
    /// </summary>
    public partial class ForgotPassWin : Window
    {
        public ForgotPassWin()
        {
            InitializeComponent();
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            SignInWin signInWin = new SignInWin();
            this.Close();
            signInWin.Show();
        }
    }
}
========
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Contract_Monthly_Claim_System
{
    /// <summary>
    /// Interaction logic for ForgotPassWin.xaml
    /// </summary>
    public partial class ForgotPassWin : Window
    {
        public ForgotPassWin()
        {
            InitializeComponent();
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            SignInWin signInWin = new SignInWin();
            this.Close();
            signInWin.Show();
        }
    }
}
>>>>>>>> f5223b0132b58b7e5ac191911ee48507ddf3551d:ForgotPassWin.xaml.cs
