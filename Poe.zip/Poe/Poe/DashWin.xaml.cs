﻿using Poe;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Contract_Monthly_Claim_System
{
    /// <summary>
    /// Interaction logic for DashWin.xaml
    /// </summary>
    public partial class DashWin : Window
    {
        private string TypeUser;
        private string UserName;

        //coordinator
        //lecture
        public DashWin(string typeUser, string userName)
        {
            InitializeComponent();
            this.TypeUser = typeUser;
            MessageBox.Show($"This user is using a {this.TypeUser} account", "Message Box Title", MessageBoxButton.OK, MessageBoxImage.Information);
            this.UserName = userName;
        }

        private void BtnSub_Click(object sender, RoutedEventArgs e)
        {
            string userName = this.UserName;
            //Lecturers
            
                LecturersWin lecturersWin = new LecturersWin(userName);
                this.Hide();
                lecturersWin.ShowDialog();
                this.Show();
        }

        private void BtnClaimApp_Click(object sender, RoutedEventArgs e)
        {
            //Coordinators/Managers
            bool AreTheyAllowed = string.Equals(TypeUser, "coordinator", StringComparison.OrdinalIgnoreCase);
            if (AreTheyAllowed)
            {
                ApprovalWin approvalWin = new ApprovalWin();
                this.Hide();
                this.Show();
            }
            else
            {
                MessageBox.Show("Only Coordinators/Managers Are Authorized!!!", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void BtnViewClaim_Click(object sender, RoutedEventArgs e)
        {
            //Lecturers
            bool AreTheyAllowed = string.Equals(TypeUser, "lecture", StringComparison.OrdinalIgnoreCase);
            if (AreTheyAllowed)
            {
                ClaimStatWin claimStatWin = new ClaimStatWin();
                this.Hide();
                this.Show();
            }
            else
            {
                MessageBox.Show("Only Lectures Are Authorized!!!", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void BtnUpload_Click(object sender, RoutedEventArgs e)
        {
            //Lecturers
            bool AreTheyAllowed = string.Equals(TypeUser, "lecture", StringComparison.OrdinalIgnoreCase);
            if (AreTheyAllowed)
            {
                DocUploadWin docUploadWin = new DocUploadWin();
                this.Hide();
                this.Show();
            }
            else
            {
                MessageBox.Show("Only Lectures Are Authorized!!!", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning );
            }
        }
    }
}
