﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Contract_Monthly_Claim_System
{
    /// <summary>
    /// Interaction logic for ApprovalWin.xaml
    /// </summary>
    public partial class ApprovalWin : Window
    {
        private string PersonalFile = "..//..//..//..//Txt_Files//Login_info.txt";
        private string ClaimFile = "..//..//..//..//Txt_Files//Login_info.txt";
        private string[,] userInfo;
        private int numOfUsers;
        public ApprovalWin()
        {
            InitializeComponent();

            List<string> PersonalFileInfo = new List<string>();
            List<string> ClaimInfo = new List<string>();

            try
            {
                using(StreamReader ReadingFiles = new StreamReader(PersonalFile))
                {
                    string line;
                    while((line = ReadingFiles.ReadLine()) != null) 
                    {
                        PersonalFileInfo.Add(line);

                    }
                }
                numOfUsers = PersonalFileInfo.Count / 8;
                userInfo = new string[numOfUsers, 14];

                using (StreamReader ReadingFiles = new StreamReader(PersonalFile))
                {
                    string line;
                    while ((line = ReadingFiles.ReadLine()) != null)
                    {
                        PersonalFileInfo.Add(line);

                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show($"ERROR: {ex.Message}");
            }

            
        }

        private void BtnDisplay_Click(object sender, RoutedEventArgs e)
        {
            
        }

        private void BtnViewFile_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnApprove_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnReject_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnGoToMenu_Click(object sender, RoutedEventArgs e)
        {

        }

    }
}
