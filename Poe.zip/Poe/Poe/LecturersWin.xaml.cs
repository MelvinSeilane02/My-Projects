﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;



namespace Poe
{
    /// <summary>
    /// Interaction logic for LecturersWin.xaml
    /// </summary>
    public partial class LecturersWin : Window
    {
        private string UserName;
        private List<string> FileNames;
        public LecturersWin(string userName)
        {
            InitializeComponent();
            LstFileNames.Items.Clear();
            this.UserName = userName;
            txtRate.Text = "";
            txtTotalAmt.Text = "";
            txtTotalHours.Text = "";
            cmbMonthSelect.SelectedIndex = -1;
        }
        
        private void BtnReturn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void BtnUpload_Click(object sender, RoutedEventArgs e)
        {

            

            OpenFileDialog openFileDialog = new OpenFileDialog();

            // Allow specific file types
            openFileDialog.Filter = "PDF files (*.pdf)|*.pdf|Word documents (*.docx)|*.docx|Excel files (*.xlsx)|*.xlsx";

            // Show the dialog and check if the user selected a file
            bool? result = openFileDialog.ShowDialog(); // This returns a nullable bool in WPF

            // Show the dialog and check if the user selected a file
            if (result == true)
            {
                // Get selected file path
                string filePath = openFileDialog.FileName;

                // Check the file size (5MB limit)
                const long maxSize = 5 * 1024 * 1024; // 5MB in bytes
                FileInfo fileInfo = new FileInfo(filePath);

                if (fileInfo.Length > maxSize)
                {
                    MessageBox.Show("File size exceeds the 5MB limit.");
                }
                else
                {
                    MessageBox.Show("File is valid. Proceeding with upload.");
                    // Get the full file path
                    string fullPath = openFileDialog.FileName;

                    // Define the destination path (local directory)
                    string destinationDirectory = @"..\..\..\..\UploadDocs\"; // Change to your desired directory
                    string fileName = System.IO.Path.GetFileName(fullPath);
                    

                    

                    // Extract the file name (without the path)
                    fileName = System.IO.Path.GetFileName(fullPath);



                    LstFileNames.Items.Add(fileName);
                    // Proceed with file upload logic here
                    string destinationFilePath = System.IO.Path.Combine(destinationDirectory, fileName);
                    try
                    {
                        // Copy the file
                        File.Copy(fullPath, destinationFilePath, true); // Set overwrite to true if needed
                        MessageBox.Show($"File copied to: {destinationFilePath}");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error: {ex.Message}","Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }

        private void BtnSubmit_Click(object sender, RoutedEventArgs e)
        {
            string userName = this.UserName;

            try
            {
                // Retrieve input values
                string month = ((ComboBoxItem)((ComboBox)FindName("cmbMonthSelect")).SelectedItem).Content.ToString();
                string totalHours = txtTotalHours.Text;
                string hourlyRate = txtRate.Text;
                string totalAmount = txtTotalAmt.Text;
                // Convert ListBox items to a generic List<string>
                FileNames = LstFileNames.Items.Cast<string>().ToList();


                // Check if any field is empty
                if (string.IsNullOrWhiteSpace(totalHours) || string.IsNullOrWhiteSpace(hourlyRate) || string.IsNullOrWhiteSpace(totalAmount) || cmbMonthSelect.SelectedItem == null)
                {
                    MessageBox.Show("Please fill in all the fields before submitting the claim.", "Missing Information", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return; // Exit the method if any field is empty
                }


                string filePath = @$"..\..\..\..\Txt_Files\{userName}.txt";

                // Create the StreamWriter and overwrite the file if it exists
                using (StreamWriter editFile = new StreamWriter(filePath, false))
                {
                    // This will overwrite the content of the file
                    editFile.WriteLine($"pending\n{month}\n{totalHours}\n{hourlyRate}\n{totalAmount}");
                    if (FileNames.Count > 0)
                    {
                        editFile.Write(FileNames[0]);
                        for (int i = 1; i < FileNames.Count; i++)
                            editFile.Write($",{FileNames[i]}");
                    }
                    editFile.WriteLine();
                    MessageBox.Show("Claim submitted successfully.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("The file could not be read:", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                MessageBox.Show(ex.Message);
            }
        }

    private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (LstFileNames.SelectedItem != null)
            {
                string destinationDirectory = @"..\..\..\..\UploadDocs\";


                // Get the selected item
                String DeletedDoc = LstFileNames.SelectedItem.ToString();
                string destinationFilePath = System.IO.Path.Combine(destinationDirectory, DeletedDoc);
                try
                {
                    File.Delete(destinationFilePath);
                    MessageBox.Show($"File deleted from: {destinationFilePath}","Info", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}");
                }

                int selectedIndex = LstFileNames.SelectedIndex;
                LstFileNames.Items.RemoveAt(selectedIndex);
            }
            else
            {
                MessageBox.Show("Select A File To Delete!!!", "Warning",MessageBoxButton.OK,MessageBoxImage.Warning);
            }
        }

        private void BtnCalculate_Click(object sender, RoutedEventArgs e)
        {
            if(!(string.IsNullOrWhiteSpace(txtTotalHours.Text) && string.IsNullOrWhiteSpace(txtRate.Text)))
            {
                try
                {
                    Double Rate = double.Parse(txtRate.Text);
                    Double TotalHours = double.Parse(txtTotalHours.Text);
                    double TotalAmt = Rate * TotalHours;

                    txtTotalAmt.Text = $"{TotalAmt}";
                }
                catch(Exception eg)
                {
                    MessageBox.Show($"Error {eg.Message}","Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                    txtRate.Clear();
                    txtTotalHours.Clear();
                    txtTotalHours.Focus();
                }
            }
        }
    }
}
