﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;
//using System.Windows.Forms;

namespace Contract_Monthly_Claim_System
{
    /// <summary>
    /// Interaction logic for SignInWin.xaml
    /// </summary>
    public partial class SignInWin : Window
    {
        public SignInWin()
        {
            InitializeComponent();
        }

        private string[,] userInfo;
        private int numOfUser;
        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            if (!(string.IsNullOrWhiteSpace(TxtUsername.Text) && string.IsNullOrWhiteSpace(TxtPassword.Text)))
            {
                List<string> loginData = new List<string>();
                List<string> tempUserName = new List<string>();
                List<string> tempPass = new List<string>();
                List<string> tempTypeUser = new List<string>();
                string LoginFile = "..//..//..//..//Txt_Files//Login_info.txt";

                try
                {
                    // Create a StreamReader
                    using (StreamReader reader = new StreamReader(LoginFile))
                    {
                        string line;

                        // Read line by line
                        while ((line = reader.ReadLine()) != null)
                        {
                            loginData.Add(line);
                        }


                    }
                }
                catch (Exception exp)
                {
                    Console.WriteLine(exp.Message);
                }

                numOfUser = loginData.Count/8;
                for (int i = 1; i <= numOfUser; i++)
                {
                    tempUserName.Add(loginData[(6*i)]);
                    tempPass.Add(loginData[7*1]);
                    tempTypeUser.Add(loginData[5*i]);
                }

                string[] userNames = tempUserName.ToArray();
                string[] userPasses = tempPass.ToArray();
                string[] TypeUsers = tempTypeUser.ToArray();

                for (int i = 0;i < userNames.Length; i++)
                {
                    if (TxtUsername.Text.Equals(userNames[i]) && TxtPassword.Text.Equals(userPasses[i]))
                    {
                        string userName = userNames[i];
                        string TypeUser = TypeUsers[i];
                        DashWin dashWin = new DashWin(TypeUser, userName);
                        MessageBox.Show($"Welcome user {userNames[i]}", "Login Successful");
                        dashWin.Show();
                        this.Close();
                        break;
                    }
                    else if(i == (userNames.Length - 1))
                    {
                        // Display a message box with a warning icon
                        MessageBox.Show("Incorrect Username or Password!!!", "Warning");
                    }
                    
                }
            }
            else
            {
                MessageBox.Show("Fill In All The Boxes!!!", "Warning");
            }

        }

        private void BtnSignUp_Click(object sender, RoutedEventArgs e)
        {
            RegistrationWin registrationWin = new RegistrationWin();
            this.Hide();
            registrationWin.ShowDialog();
            this.Show();
        }
    }
}
