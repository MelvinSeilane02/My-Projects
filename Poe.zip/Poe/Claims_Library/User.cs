﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Claims_Library
{
    public class User
    {
        private String UserID = "", Name, Surname, Gender, Email, UserName, Password, Verify, Month, Department ;
        private double TotalHours, TotalAmount, HourlyRate;
        private List<string> Documents = new List<string>();

        public User(string userID,string name,string surname,string gender, string email,string department, string userName, string password)
        {
            this.UserID = userID;
            this.Name = name;
            this.Surname = surname;
            this.Gender = gender;
            this.Email = email;
            this.Department = department;
            this.UserName = userName;
            this.Password = password;
            
        }
        public string verify { get => Verify; set => Verify = value; }
        public string month { get => Month; set => Month = value; }
        public double totalHours { get => TotalHours; set => TotalHours = value ; }
        public double totalAmount { get => TotalAmount; set => TotalAmount = value; }
        public double houelyRate { get => HourlyRate; set => HourlyRate = value; }
        public List<String> documents { 
            get => Documents;}
        public void AddDocument(string document)
        {
            Documents.Add(document);
        }

        //Get User Personal Data
        public string userID { get => UserID; }
        public string name { get => Name; }
        public string surname { get => Surname;}
        public string gender { get => Gender; }
        public string email { get => Email; }
        public string department { get => Department;}
        public string userName { get => UserName; }
        public string password { get => Password; }

       
    }
}
